/*

import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ProductService } from 'src/app/entities/product/product.service';
import { IProduct, Product } from 'src/app/entities/product/product.model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
//^ keep product services or new for cart???

@Component({
  selector: 'app-cart-add',
  templateUrl: './cart-add.component.html',
  styleUrls: ['./cart-add.component.css']
})
export class CartAddComponent implements OnInit {

  cartitems: Array<IProduct> = [];

  constructor(protected productService: ProductService) { }

    //Add item to cart:
    addToCart(id: string) {
      this.cartitems.push(this.productToDisplay);
    }
}
*/