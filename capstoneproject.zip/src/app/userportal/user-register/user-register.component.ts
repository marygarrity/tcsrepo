import { Component, OnInit, Output, EventEmitter } from '@angular/core';
//import UserService from user.service.ts:
import { UserService } from 'src/app/entities/user/user.service';
//import IUser, User from user.model.ts:
import { IUser, User } from 'src/app/entities/user/user.model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-register',//changed to register
  templateUrl: './user-register.component.html',//changed to register
  styleUrls: ['./user-register.component.css']//changed to register
})

//export class UserRegisterComponent:
export class UserRegisterComponent implements OnInit {//changed to register

  //user form: 
  userForm: FormGroup;

  //attributes:
  name: string = '';
  email: string = '';
  password: string = '';
  type: string = '';

  //error:
  error: boolean = false;

  @Output() createdUser = new EventEmitter<IUser>();

  constructor(protected userService: UserService, protected formBuilder: FormBuilder) { }

  // Init the form when starting the view.
  ngOnInit(): void {
    this.initForm();
  }

  // Manage the submit action and create the new user
  onSubmit() {
    //create new user: 
    const user = new User(this.userForm.value['name'], this.userForm.value['email'], this.userForm.value['password'], this.userForm.value['type'], null);

    this.userService.create(user).then((result: IUser) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.createdUser.emit(result);
      }
    });
  }

  // Hide the error message.
  hideError() {
    this.error = false;
  }

  // Init the creation form.
  private initForm() {
    this.userForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      email: new FormControl(this.email, Validators.required),
      password: new FormControl(this.password, Validators.required),
      type: new FormControl(this.type, Validators.required)
    });
  }
}