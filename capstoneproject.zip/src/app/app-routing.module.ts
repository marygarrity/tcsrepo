import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//importing components: 

//for register/sign in:


//for admin portal:
import { ProductCreateComponent } from "src/app/adminportal/product/product-create/product-create.component";
import { ProductListComponent } from "src/app/adminportal/product/product-list/product-list.component";
import { UserCreateComponent } from "src/app/adminportal/user/user-create/user-create.component";
import { UserListComponent } from "src/app/adminportal/user/user-list/user-list.component";

import { ProductUpdateComponent } from "src/app/adminportal/product/product-update/product-update.component";

//for user portal:


//paths:
const routes: Routes = [
  { path: 'product-create', component: ProductCreateComponent },
  { path: 'product-list', component: ProductListComponent },
  { path: 'user-create', component: UserCreateComponent },
  { path: 'user-list', component: UserListComponent },

  { path: 'product-update/:id', component: ProductUpdateComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
