import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { ProductService } from 'src/app/entities/product/product.service';
import { IProduct, Product } from 'src/app/entities/product/product.model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-product-update',
  templateUrl: './product-update.component.html',
  styleUrls: ['./product-update.component.css']
})
export class ProductUpdateComponent implements OnInit {

  productForm: FormGroup;
  name: string = '';
  brand: string = '';
  error: boolean = false;
  price: string = '';
  email: string = '';
  availability: string = '';

  //adding product id:
  product_id: string = '';
  found_product_id: string = '';

  //create "sub"
  sub;

  //declare array with list of all products:
  products: Array<IProduct> = [];

  @Output() createdProduct = new EventEmitter<IProduct>();

  constructor(protected productService: ProductService, protected formBuilder: FormBuilder, 
    private _Activatedroute: ActivatedRoute, private _router: Router) { }

  // Init the form when starting the view.
  ngOnInit(): void {
    this.initForm();
  }

  // Manage the submit action and create the new product.
  onSubmit() {
    //adding price, email, availability:
    const product = new Product(this.productForm.value['name'], this.productForm.value['brand'], this.productForm.value['price'], this.productForm.value['email'], this.productForm.value['availability'], null);
    this.productService.create(product).then((result: IProduct) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.createdProduct.emit(result);
      }
    });
  }

  // Hide the error message.
  hideError() {
    this.error = false;
  }

  // Init the creation form.
  private initForm() {
    //getting product_id from url parameter:
    this.sub = this._Activatedroute.paramMap.subscribe(params => {
      this.product_id = params.get('id');
    });

    //call loadAll
    this.loadAll();

    //iterate through collection to find record (ForEach loop):
    for(let p of this.products){
      if (p._id == this.product_id)
      {
        this.found_product_id = p._id;
        break;
      }
    }

    this.productForm = new FormGroup({
      name: new FormControl(this.products[this.found_product_id].name, Validators.required),
      brand: new FormControl(this.products[this.found_product_id].brand, Validators.required),
      //adding price, email, availability:
      price: new FormControl(this.products[this.found_product_id].price, Validators.required),
      email: new FormControl(this.products[this.found_product_id].email, Validators.required),
      availability: new FormControl(this.products[this.found_product_id].availability, Validators.required)
    });
  }

  //OnDestroy:
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  private loadAll() {
    this.productService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }
}