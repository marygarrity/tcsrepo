import { Component, OnInit, Input, OnChanges } from '@angular/core';
//import UserService from user.service.ts:
import { UserService } from 'src/app/entities/user/user.service';
//import IUser from user.model.ts:
import { IUser } from 'src/app/entities/user/user.model';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})

//export class UserListComponent:
export class UserListComponent implements OnInit, OnChanges {

  //users array:
  users: Array<IUser> = [];
  
  @Input() userToDisplay: IUser = null;

  constructor(protected userService: UserService) { }

  // Load all the products when starting the view.
  ngOnInit(): void {
    this.loadAll();
  }

  // If new user created, we add it to the list:
  ngOnChanges(): void {
    if (this.userToDisplay !== null) {
      this.users.push(this.userToDisplay);
    }
  }

  // Delete user (DELETE):
  delete(id: string) {
    this.userService.delete(id).then((result: any) => this.loadAll());
  }

  //Add "update" (PUT): 

  // Load all users (GET):
  private loadAll() {
    this.userService
      .get()
      .then((result: Array<IUser>) => {
        this.users = result;
      });
  }
}