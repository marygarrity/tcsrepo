export interface IProduct {
  _id?: string;
  name: string;
  brand: string;
  //adding price, email, availability:
  price: string;
  email: string;
  availability: string;//string?
}

export class Product implements IProduct {
  constructor(
    public name: string,
    public brand: string,
    //adding price, email, availability:
    public price: string,
    public email: string,
    public availability: string,//string?
    public _id?: string
  ) {
    this._id = _id ? _id : null;
    this.name = name;
    this.brand = brand;
    //adding price, email, availability:
    this.price = price;
    this.email = email;
    this.availability = availability;
  }
}