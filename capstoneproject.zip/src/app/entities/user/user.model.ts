//interface IUser:
export interface IUser {

    //user has name, email, password
    _id?: string;
    name: string;
    email: string;
    password: string;
    type: string;

    //add unique constraints later
}
  
//export User class (implements IUser):
export class User implements IUser {
    constructor(
        public name: string,
        public email: string,
        public password: string,
        public type: string,
        public _id?: string
    ) {
        this._id = _id ? _id : null;
        this.name = name;
        this.email = email;
        this.password = password;
        this.type = type;
    }
}