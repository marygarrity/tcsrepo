import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Compiler } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { ProductListComponent } from './adminportal/product/product-list/product-list.component';
import { ProductCreateComponent } from './adminportal/product/product-create/product-create.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserCreateComponent } from './adminportal/user/user-create/user-create.component';
import { UserListComponent } from './adminportal/user/user-list/user-list.component';
//adding UserRegisterComponent import:
import { UserRegisterComponent } from './userportal/user-register/user-register.component';
//adding UserShopComponent import:
import { UserShopComponent } from './userportal/user-shop/user-shop.component';
//adding AddCartComponent import:
//import { CartAddComponent } from './userportal/cart-add/cart-add.component';
//adding ProductModifyComponent import:
//import { ProductModifyComponent } from './adminportal/product/product-modify/product-modify.component';
import { ProductUpdateComponent } from './adminportal/product/product-update/product-update.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ProductCreateComponent,
    UserCreateComponent,
    UserListComponent,
    //adding UserRegisterComponent:
    UserRegisterComponent,
    //adding UserShopComponent:
    UserShopComponent,
    //adding AddCartComponent:
    //CartAddComponent,
    //adding ProductModifyComponent:
    //ProductModifyComponent,
    ProductUpdateComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    //adding app routing:
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
